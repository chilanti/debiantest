mv /tmp/knapp /usr/local/bin/knapp
chmod 755 /usr/local/bin/knapp
knapp init
mv /tmp/knapp-watcher $HOME/.knapp/knapp-watcher
